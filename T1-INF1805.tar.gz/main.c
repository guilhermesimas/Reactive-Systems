#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <assert.h>
#include <string.h>
#define ROUND_BEGINNING_INTERVAL 30000
#define INTERVAL_DECREASE 2000
#define NUMBER_SQUARES 4
#define SQUARE_SIZE 30
#define WINDOW_WIDTH 640
#define WINDOW_HEIGHT 480
#define PLAYER_SIZE 50
#define PLAYER_VELOCITY 5
#define PLAYER_START_POSITION_X 200
#define PLAYER_START_POSITION_Y 200
#define MAXIMUM_SIZE_STRING 30
#define STRING_MESSAGE "Time remaining:"
#define TEXT_WIDTH 180
#define TEXT_HEIGHT 50
void generateSquares(SDL_Rect* squares[],SDL_Rect user);
int gotSquare (SDL_Rect* squares[],SDL_Rect user);
int main (int argc, char* args[])
{
    int i,squaresCollected=0,userVelocityX=0,userVelocityY=0;
    char keepGoing=1,startScreen=1;
    SDL_Surface *message=NULL,*windowSurface,*imageSurface;
    SDL_Texture *messageTexture=NULL,*imageTexture;
    TTF_Font *font=NULL;
    SDL_Rect messageBox= {WINDOW_WIDTH-TEXT_WIDTH,0,TEXT_WIDTH,TEXT_HEIGHT};
    int err = SDL_Init(SDL_INIT_EVERYTHING);
    char stringTimerMessage[MAXIMUM_SIZE_STRING],stringTimerNumber[MAXIMUM_SIZE_STRING];
    assert(err == 0);
    SDL_Window* window = SDL_CreateWindow("Collect the Squares!",SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
    assert(window != NULL);
    windowSurface=SDL_GetWindowSurface(window);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, 0);
    assert(renderer != NULL);
    assert(TTF_Init()!=-1);
    font=TTF_OpenFont("Sources/font.ttf",50);
    if(font==NULL) printf("\nTTF_OpenFont: %s\n", TTF_GetError());
    SDL_Color textColor= {0,0,0},white= {255,255,255};
    long timeSinceStartOfRound=0,roundInterval=ROUND_BEGINNING_INTERVAL;
    SDL_Rect user = { PLAYER_START_POSITION_X,PLAYER_START_POSITION_Y, PLAYER_SIZE, PLAYER_SIZE },*collectibles[NUMBER_SQUARES];
    SDL_Event e;
    for(i=0; i<NUMBER_SQUARES; i++)
    {
        collectibles[i]=(SDL_Rect*)malloc(sizeof(SDL_Rect));
        collectibles[i]->h=SQUARE_SIZE;
        collectibles[i]->w=SQUARE_SIZE;
    }
    while(keepGoing==1)
    {
        if(startScreen==1)
        {
            imageSurface=SDL_LoadBMP("Sources/telaEntrada.bmp");
            imageTexture=SDL_CreateTextureFromSurface(renderer,imageSurface);
            SDL_FreeSurface(imageSurface);
            SDL_RenderCopy(renderer,imageTexture,NULL,NULL);
            SDL_RenderPresent(renderer);
            while(1)
            {
                while(SDL_PollEvent==0) ;
                if(SDL_PollEvent(&e)!=0)
                {
                    if(e.type==SDL_QUIT)
                    {
                        startScreen=0;
                        keepGoing=0;
                        break;
                    }
                    if(e.type==SDL_KEYDOWN)
                    {
                        if(e.key.keysym.sym==SDLK_SPACE)
                        {
                            imageSurface=SDL_LoadBMP("Sources/telaPreJogo1.bmp");
                            imageTexture=SDL_CreateTextureFromSurface(renderer,imageSurface);
                            SDL_FreeSurface(imageSurface);
                            SDL_RenderCopy(renderer,imageTexture,NULL,NULL);
                            SDL_RenderPresent(renderer);
                            SDL_Delay(1000);
                            imageSurface=SDL_LoadBMP("Sources/telaPreJogo2.bmp");
                            imageTexture=SDL_CreateTextureFromSurface(renderer,imageSurface);
                            SDL_FreeSurface(imageSurface);
                            SDL_RenderCopy(renderer,imageTexture,NULL,NULL);
                            SDL_RenderPresent(renderer);
                            SDL_Delay(1000);
                            imageSurface=SDL_LoadBMP("Sources/telaPreJogo3.bmp");
                            imageTexture=SDL_CreateTextureFromSurface(renderer,imageSurface);
                            SDL_FreeSurface(imageSurface);
                            SDL_RenderCopy(renderer,imageTexture,NULL,NULL);
                            SDL_RenderPresent(renderer);
                            SDL_Delay(1000);
                            user.x=PLAYER_START_POSITION_X;
                            user.y=PLAYER_START_POSITION_Y;
                            userVelocityX=0;
                            userVelocityY=0;
                            generateSquares(collectibles,user);
                            timeSinceStartOfRound=SDL_GetTicks();
                            roundInterval=ROUND_BEGINNING_INTERVAL;
                            squaresCollected=0;
                            startScreen=0;
                            keepGoing=1;
                            break;
                        }
                    }
                }
            }
        }
        else
        {
            int i;
            if(SDL_PollEvent(&e)!=0)
            {
                if (e.type == SDL_QUIT)
                {
                    break;
                }
                else if (e.type == SDL_KEYDOWN)
                {
                    switch (e.key.keysym.sym)
                    {
                    case SDLK_UP:
                        userVelocityY = -PLAYER_VELOCITY;
                        userVelocityX = 0;
                        break;
                    case SDLK_DOWN:
                        userVelocityY = PLAYER_VELOCITY;
                        userVelocityX = 0;
                        break;
                    case SDLK_LEFT:
                        userVelocityX = -PLAYER_VELOCITY;
                        userVelocityY = 0;
                        break;
                    case SDLK_RIGHT:
                        userVelocityX = PLAYER_VELOCITY;
                        userVelocityY = 0;
                        break;
                    }
                }
            }
            else SDL_Delay(17);
            squaresCollected+=gotSquare(collectibles,user);
            if(squaresCollected==NUMBER_SQUARES)
            {
                timeSinceStartOfRound=SDL_GetTicks();
                roundInterval-=INTERVAL_DECREASE;
                generateSquares(collectibles,user);
                squaresCollected=0;
            }
            strcpy(stringTimerMessage,STRING_MESSAGE);
            sprintf(stringTimerNumber,"%d.%03d",(roundInterval-(SDL_GetTicks()-timeSinceStartOfRound))/1000,(roundInterval-(SDL_GetTicks()-timeSinceStartOfRound))%1000 );
            strcat(stringTimerMessage,stringTimerNumber);
            message=TTF_RenderText_Blended(font,stringTimerMessage,textColor);
            assert(message!=NULL);
            messageTexture=SDL_CreateTextureFromSurface(renderer,message);
            SDL_FreeSurface(message);
            SDL_SetRenderDrawColor(renderer, 0xFF,0xFF,0xFF,0x00);
            SDL_RenderFillRect(renderer, NULL);
            user.x+=userVelocityX;
            user.y+=userVelocityY;
            if(user.x<0||user.x>WINDOW_WIDTH-PLAYER_SIZE||user.y<0||user.y>WINDOW_HEIGHT-PLAYER_SIZE)
            {
                user.x-=userVelocityX;
                user.y-=userVelocityY;
            }
            SDL_SetRenderDrawColor(renderer, 0x00,0x00,0xFF,0x00);
            SDL_RenderFillRect(renderer, &user);
            SDL_SetRenderDrawColor(renderer,0x00,0xFF,0x00,0x00);
            for(i=0; i<NUMBER_SQUARES; i++)
            {
                SDL_RenderFillRect(renderer,collectibles[i]);
            }
            SDL_SetRenderDrawColor(renderer,0xFF,0,0,0);
            SDL_RenderCopy(renderer,messageTexture,NULL,&messageBox);
            SDL_RenderPresent(renderer);
            if(SDL_GetTicks()-timeSinceStartOfRound > roundInterval)
            {
                imageSurface=SDL_LoadBMP("Sources/telaGameOver.bmp");
                imageTexture=SDL_CreateTextureFromSurface(renderer,imageSurface);
                SDL_FreeSurface(imageSurface);
                SDL_RenderCopy(renderer,imageTexture,NULL,NULL);
                SDL_RenderPresent(renderer);
                while(1)
                {
                    while(SDL_PollEvent==0) ;
                    if(SDL_PollEvent(&e)!=0)
                    {
                        if(e.type==SDL_QUIT)
                        {
                            startScreen=0;
                            keepGoing=0;
                            break;
                        }
                        if(e.type==SDL_KEYDOWN)
                        {
                            if(e.key.keysym.sym==SDLK_SPACE)
                            {
                                startScreen=1;
                                keepGoing=1;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
void generateSquares(SDL_Rect* squares[],SDL_Rect user)
{
    int i;
    for(i=0; i<NUMBER_SQUARES; i++)
    {
        int isUniqueSeed;
        long randomSeedX,randomSeedY;
        do
        {
            isUniqueSeed=1;
            randomSeedX=(SDL_GetTicks()*SDL_GetTicks()) % (WINDOW_WIDTH-SQUARE_SIZE+1);
            randomSeedY=(SDL_GetTicks()*SDL_GetTicks()) % (WINDOW_HEIGHT-SQUARE_SIZE+1);
            if(     (((randomSeedX>=user.x-SQUARE_SIZE)&&(randomSeedX<=user.x+PLAYER_SIZE)) && ((randomSeedY>=user.y-SQUARE_SIZE)&&(randomSeedY<=user.y+PLAYER_SIZE))  ) )
            {
                isUniqueSeed=0;
            }
            else
            {
                int j;
                for(j=0; j<i; j++)
                {
                    if( ((randomSeedX>=squares[j]->x-SQUARE_SIZE)&&(randomSeedX<=squares[j]->x+SQUARE_SIZE)) && ((randomSeedY>=squares[j]->y-SQUARE_SIZE)&&(randomSeedY<=squares[j]->y+SQUARE_SIZE))   )
                    {
                        isUniqueSeed=0;
                        break;
                    }
                }
            }
        }
        while(isUniqueSeed==0);
        squares[i]->x=randomSeedX;
        squares[i]->y=randomSeedY;
    }
}
int gotSquare (SDL_Rect* squares[],SDL_Rect user)
{
    int i,squaresCollected=0;
    for(i=0; i<NUMBER_SQUARES; i++)
    {
        if( ((squares[i]->x>=user.x-SQUARE_SIZE)&&(squares[i]->x<=user.x+PLAYER_SIZE))
                && ((squares[i]->y>=user.y-SQUARE_SIZE)&&(squares[i]->y<=user.y+PLAYER_SIZE))   )
        {
            squares[i]->x=-SQUARE_SIZE;
            squares[i]->y=-SQUARE_SIZE;
            squaresCollected++;
        }
    }
    return squaresCollected;
}
